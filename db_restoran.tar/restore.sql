--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.userr DROP CONSTRAINT userr_pkey;
ALTER TABLE ONLY public.userr DROP CONSTRAINT userr_id_user_key;
ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_pkey;
ALTER TABLE ONLY public.transaksi DROP CONSTRAINT transaksi_id_transaksi_key;
ALTER TABLE ONLY public.tb_masakan DROP CONSTRAINT tb_masakan_pkey;
ALTER TABLE ONLY public.tb_masakan DROP CONSTRAINT tb_masakan_id_masakan_key;
ALTER TABLE ONLY public.orderr DROP CONSTRAINT orderr_pkey;
ALTER TABLE ONLY public.orderr DROP CONSTRAINT orderr_id_order_key;
ALTER TABLE ONLY public.level DROP CONSTRAINT level_pkey;
ALTER TABLE ONLY public.detai_order DROP CONSTRAINT detai_order_pkey;
DROP TABLE public.userr;
DROP TABLE public.transaksi;
DROP TABLE public.tb_masakan;
DROP TABLE public.orderr;
DROP TABLE public.level;
DROP TABLE public.detai_order;
DROP TYPE public.status_order_detail;
DROP TYPE public.status_order;
DROP TYPE public.status_masakan;
DROP TYPE public.masakan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: masakan; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE masakan AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE masakan OWNER TO postgres;

--
-- Name: status_masakan; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_masakan AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE status_masakan OWNER TO postgres;

--
-- Name: status_order; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_order AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE status_order OWNER TO postgres;

--
-- Name: status_order_detail; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE status_order_detail AS ENUM (
    'Selesai',
    'Belum'
);


ALTER TYPE status_order_detail OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detai_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detai_order (
    id_detail character varying NOT NULL,
    id_order character varying(10),
    id_masakan character varying(10),
    keterangan text,
    status_order_detail status_order_detail
);


ALTER TABLE detai_order OWNER TO postgres;

--
-- Name: level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE level (
    id_level character varying NOT NULL,
    nama_level character varying(20)
);


ALTER TABLE level OWNER TO postgres;

--
-- Name: orderr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE orderr (
    id_order character varying NOT NULL,
    no_meja integer,
    tanggal date,
    id_user character varying(10),
    keterangan character varying(10),
    status_order status_order
);


ALTER TABLE orderr OWNER TO postgres;

--
-- Name: tb_masakan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_masakan (
    id_masakan character varying NOT NULL,
    nama_masakan character varying(50),
    harga integer,
    status_masakan status_masakan
);


ALTER TABLE tb_masakan OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi character varying NOT NULL,
    id_user character varying(10),
    id_order character varying(10),
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Name: userr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE userr (
    id_user character varying NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_user character varying(50),
    id_level character varying(10)
);


ALTER TABLE userr OWNER TO postgres;

--
-- Data for Name: detai_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detai_order (id_detail, id_order, id_masakan, keterangan, status_order_detail) FROM stdin;
\.
COPY detai_order (id_detail, id_order, id_masakan, keterangan, status_order_detail) FROM '$$PATH$$/2850.dat';

--
-- Data for Name: level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY level (id_level, nama_level) FROM stdin;
\.
COPY level (id_level, nama_level) FROM '$$PATH$$/2851.dat';

--
-- Data for Name: orderr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY orderr (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2849.dat';

--
-- Data for Name: tb_masakan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY tb_masakan (id_masakan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2852.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2847.dat';

--
-- Data for Name: userr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY userr (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY userr (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2848.dat';

--
-- Name: detai_order detai_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detai_order
    ADD CONSTRAINT detai_order_pkey PRIMARY KEY (id_detail);


--
-- Name: level level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY level
    ADD CONSTRAINT level_pkey PRIMARY KEY (id_level);


--
-- Name: orderr orderr_id_order_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orderr
    ADD CONSTRAINT orderr_id_order_key UNIQUE (id_order);


--
-- Name: orderr orderr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY orderr
    ADD CONSTRAINT orderr_pkey PRIMARY KEY (id_order);


--
-- Name: tb_masakan tb_masakan_id_masakan_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_masakan
    ADD CONSTRAINT tb_masakan_id_masakan_key UNIQUE (id_masakan);


--
-- Name: tb_masakan tb_masakan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_masakan
    ADD CONSTRAINT tb_masakan_pkey PRIMARY KEY (id_masakan);


--
-- Name: transaksi transaksi_id_transaksi_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_id_transaksi_key UNIQUE (id_transaksi);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: userr userr_id_user_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY userr
    ADD CONSTRAINT userr_id_user_key UNIQUE (id_user);


--
-- Name: userr userr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY userr
    ADD CONSTRAINT userr_pkey PRIMARY KEY (id_user);


--
-- PostgreSQL database dump complete
--

